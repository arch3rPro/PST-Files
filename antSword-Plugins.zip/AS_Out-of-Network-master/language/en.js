module.exports = {
  title: "Out-of-Network",
  success: "success",
  error: "fail",
  tips: {
    init: 'Press Start Checking',
    checking: 'Checking...',
  },
  toolbar: {
    start: "Start",
    reset: "Reset",
  },
}
