module.exports = {
  title: "出网探测",
  success: "操作成功",
  error: "操作失败",
  tips: {
    init: '点击开始按钮检测',
    checking: '检测中...',
  },
  toolbar: {
    start: "开始",
    reset: "重置",
  },
}
