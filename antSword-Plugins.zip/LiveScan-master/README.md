# AntSword LiveScan

> AntSword Webshell存活弹出插件

1. 通过请求 Webshell 并判断返回数据是否一致判断 Webshell 是否存活
2. 仅对 PHP,ASP,ASPX 有效
3. 一键将失联的 Webshell 移动到 **[.Trash]**分类
4. 一键清空**[.Trash]**分类

## 安装

### 商店安装

进入 AntSword 插件中心，选择 LiveScan, 点击安装

### 手动安装

1. 获取源代码

    ```
    git clone https://github.com/Virink/LiveScan.git
    ```

2. 拷贝源代码至插件目录

    将插件目录拷贝至 `antSword/antData/plugins/` 目录下即安装成功

## TODO

**No TODO**

凑合着用吧

## 相关链接

* [AntSword 文档](http://doc.uyu.us)
* [dhtmlx 文档](http://docs.dhtmlx.com/)
