module.exports = {
    title: "ExecuteScript",
    success: "Success",
    error: "Fail",
    cella: {
        title: "Editer",
        start: "Execute",
        clear:  "Clean",
        script: "Type:",
    },
    cellb: {
        title: "Result",
    }
}