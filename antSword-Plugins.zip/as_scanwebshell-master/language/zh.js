module.exports = {
  title: "WebShell查杀",
  success: "操作成功",
  error: "操作失败",
  toolbar: {
    start: "开始",
  },
  grid: {
    name: "文件",
    line: "行号",
    code: "可疑代码",
  },
}