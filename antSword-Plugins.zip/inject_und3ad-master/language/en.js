/**
 * en_US
 */

module.exports = {
    title: "Inject the undead php webshell",
    toolbar: {
        new: "New remote control file"
    },
    message: {
        inject_success: "Successfully inject! The address of remote control file has been recorded!"
    },
    prompt: {
        rm_file: "Please enter the remote control file address and timeout's value(spilted by ###)"
    },
    cell:{
        path:"Remote control file history"
    },
    error:{
        wrong:"Injection fail!",
        value_wrong:"Illegal input ! Please check your input!"
    }

};