module.exports = {
  title: "JWT-Debugger",
  success: "success",
  error: "fail",
  toolbar: {
    start: "Start",
    reset: "Reset",
  },
}
