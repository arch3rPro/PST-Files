module.exports = {
  title: "批量导入Shell",
  success: "成功",
  error: {
    parse: "解析 CSV 错误",
    import: "导入 Shell 数据失败"
  },
  form: {
    title: "选择 & 导入",
    path: "路径",
    choose: "选择",
    import: "导入"
  },
  grid: {
    header: {
      note: "备注",
      pass: " 密码",
      type: "类型",
      url: "地址",
      cate: "分类"
    }
  }
}
